package playerStrategy;

import characterKind.DecoratorKind;

public class AtaqueEspecial implements StrategyInterface {
	
	@Override
	public void performTurn(DecoratorKind kind) {
		kind.ataqueEspecial();
	}

}
