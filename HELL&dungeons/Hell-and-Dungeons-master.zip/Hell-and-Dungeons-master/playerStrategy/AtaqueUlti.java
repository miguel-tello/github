package playerStrategy;

import characterKind.DecoratorKind;

public class AtaqueUlti implements StrategyInterface {

	@Override
	public void performTurn(DecoratorKind kind) {
		kind.usarUlti();
	}

}