package playerStrategy;

import characterKind.DecoratorKind;

public class AtaqueNormal implements StrategyInterface {

	@Override
	public void performTurn(DecoratorKind kind) {
		kind.ataqueNormal();
	}

}
