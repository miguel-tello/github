package playerStrategy;

import characterKind.DecoratorKind;

public class Andar implements StrategyInterface{

	private String sTurn = "sigue andando";
	
	public String getsTurn() {
		return sTurn;
	}

	@Override
	public void performTurn(DecoratorKind kind) {
		System.out.println(this.getsTurn());
	}
}
