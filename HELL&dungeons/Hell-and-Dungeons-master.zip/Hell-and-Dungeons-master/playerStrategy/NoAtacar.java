package playerStrategy;

import characterKind.DecoratorKind;

public class NoAtacar implements StrategyInterface {

	private String sTurn = "ha dejado pasar el turno";
	
	public String getsTurn() {
		return sTurn;
	}
	
	@Override
	public void performTurn(DecoratorKind kind) {
		System.out.print(this.getsTurn());
	}

}