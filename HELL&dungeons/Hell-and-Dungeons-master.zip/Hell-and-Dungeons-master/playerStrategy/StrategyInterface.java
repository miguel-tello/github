package playerStrategy;

import characterKind.DecoratorKind;

public interface StrategyInterface {
	void performTurn(DecoratorKind kind);
}
