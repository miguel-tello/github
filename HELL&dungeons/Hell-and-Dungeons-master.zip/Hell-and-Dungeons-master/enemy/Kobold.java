package enemy;

public class Kobold extends Enemy{

	public Kobold() {
		this.setKind("Kobold");
		this.setLife(100);
		this.setDamage(5);
		this.setDefese(10);
	}

}
