package enemy;

public abstract class Enemy {
	
	private String sKind;
	private int iDamage;
	private int iDefense;
	private int iLife;
	
	//setters
	public void setKind(String kind) {
		this.sKind = kind;
	}
	public void setLife(int life) {
		this.iLife = life;
	}
	public void setDefese(int def) {
		this.iDefense = def;
	}
	public void setDamage(int dama) {
		this.iDamage = dama;
	}
	
	//getter
	public String getKind() {
		return sKind;
	}
	public int getLife() {
		return this.iLife;
	}
	public int getDamage() {
		return  this.iDamage;
	}
	public int getDefense() {
		return  this.iDefense;
	}
	
}
