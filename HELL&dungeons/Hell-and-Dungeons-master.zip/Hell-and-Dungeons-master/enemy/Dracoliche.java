package enemy;

public class Dracoliche extends Enemy{

	public Dracoliche() {
		this.setKind("Dracoliche");
		this.setLife(500);
		this.setDamage(100);
		this.setDefese(90);
	}

}
