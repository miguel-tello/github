package enemy;

public class AnySkullRat extends Enemy{

	public AnySkullRat() {
		this.setKind("Rata sin craneo");
		this.setLife(125);
		this.setDamage(30);
		this.setDefese(0);
	}

}
