package enemy;

public interface FabricaEnemies {
	Enemy createEnemies();
}
