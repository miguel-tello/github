package enemy;


public class Fabric implements FabricaEnemies{

	@Override
	public Enemy createEnemies() {
		Enemy enemigo = null;
		switch (1) {
			case 1:
				enemigo = new Demon();
				break;
			case 2:
				enemigo = new Dracoliche();
				break;
			case 3:
				enemigo = new TitanAnciano();
				break;
			case 4:
				enemigo = new SamllEsqueleton();
				break;
			case 5:
				enemigo = new AnySkullRat();
				break;
			case 6:
				enemigo = new Kobold();
				break;
			case 7:
				enemigo = new Demon();
				break;
			case 8:
				enemigo = new Demon();
				break;
			case 9:
				enemigo = new Demon();
				break;
			case 10:
				enemigo = new Demon();
				break;
		}
			
		return enemigo;
	}
	
}
