package enemy;

public class TitanAnciano extends Enemy{

	public TitanAnciano() {
		this.setKind("Titan Anciano");
		this.setLife(300);
		this.setDamage(125);
		this.setDefese(70);
	}

}
