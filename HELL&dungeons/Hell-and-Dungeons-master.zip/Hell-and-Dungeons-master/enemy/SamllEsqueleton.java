package enemy;

public class SamllEsqueleton extends Enemy{

	public SamllEsqueleton() {
		this.setKind("Esqueleto peque�o");
		this.setLife(150);
		this.setDamage(30);
		this.setDefese(5);
	}

}
