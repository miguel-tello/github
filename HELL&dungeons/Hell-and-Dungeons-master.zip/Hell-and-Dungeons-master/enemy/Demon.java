package enemy;

public class Demon extends Enemy{

	public Demon() {
		this.setKind("Demonio");
		this.setLife(250);
		this.setDamage(36);
		this.setDefese(40);
	}
		
}
