package characterKind;

import characterBreed.Character;

public class Samurai extends DecoratorKind{

	public Samurai(Character perso) {
		super(perso);
		this.personaje.setVida(10);
		this.personaje.setFuerza(14);
		this.personaje.setVelocidad(4);
		this.personaje.setInteligencia(-11);
		this.personaje.setResistencia(-5);
	}

	@Override
	public void ataqueNormal() {
		System.out.println(this.personaje.getsNombre()+" usa espadazo");
		//damage normal
	}

	@Override
	public void ataqueEspecial() {
		System.out.println(this.personaje.getsNombre()+" usa Castigo Kiai");
		//damage 21
	}

	@Override
	public void defesensa() {
		System.out.println(this.personaje.getsNombre()+" usa Presencia Atemorizadora");		
	}

	@Override
	public void usarUlti() {
		System.out.println(this.personaje.getsNombre()+" usa os Espadas como Una");		
		//da�o duplicado
	}

}
