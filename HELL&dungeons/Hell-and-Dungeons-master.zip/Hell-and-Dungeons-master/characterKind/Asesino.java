package characterKind;

import characterBreed.Character;

public class Asesino extends DecoratorKind{

	public Asesino(Character perso) {
		super(perso);
		this.personaje.setVida(-15);
		this.personaje.setFuerza(11);
		this.personaje.setVelocidad(20);
		this.personaje.setInteligencia(4);
		this.personaje.setResistencia(-10);
	}

	@Override
	public void ataqueNormal() {
		System.out.println(this.personaje.getsNombre()+" usa acuchillada");
	}

	@Override
	public void ataqueEspecial() {
		System.out.println(this.personaje.getsNombre()+" le ha lanzado un suriken");
		// damage : 10
	}

	@Override
	public void defesensa() {
		System.out.println(this.personaje.getsNombre()+" intentara defenderse con lo que puede");
	}

	@Override
	public void usarUlti() {
		System.out.println(this.personaje.getsNombre()+" usa una habilidad \n para aumentar el da�o y velocidad");
		// da�o *1.25
		// velocidad * 2
	}

}
