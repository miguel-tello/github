package characterKind;

import characterBreed.Character;

public class WuJen extends DecoratorKind{

	public WuJen(Character perso) {
		super(perso);
		this.personaje.setFuerza(20);
		this.personaje.setVelocidad(10);
		this.personaje.setInteligencia(20);
		this.personaje.setResistencia(-30);
	}

	@Override
	public void ataqueNormal() {
		System.out.println(this.personaje.getsNombre()+" usa rayo de hielo");
		// reduce velocidad enemigo
	}

	@Override
	public void ataqueEspecial() {
		System.out.println(this.personaje.getsNombre()+" se ba�a mientras toma una copa de vino");
	}

	@Override
	public void defesensa() {
		System.out.println(this.personaje.getsNombre()+" usa proteccion contra energia");
	}

	@Override
	public void usarUlti() {
		System.out.println(this.personaje.getsNombre()+" usa carro de fuego.\n Sus enemigos mueren instantaneamente");
	}

}
