package characterKind;

import characterBreed.Character;

public class Picaro extends DecoratorKind{

	public Picaro(Character perso) {
		super(perso);
		this.personaje.setVida(-7);
		this.personaje.setFuerza(3);
		this.personaje.setVelocidad(12);
		this.personaje.setInteligencia(3);
		this.personaje.setResistencia(-14);
	}

	@Override
	public void ataqueNormal() {
		System.out.println(this.personaje.getsNombre()+" usa acuchillada");
	}

	@Override
	public void ataqueEspecial() {
		System.out.println(this.personaje.getsNombre()+" usa ataque furtivo");
	}

	@Override
	public void defesensa() {
		System.out.println(this.personaje.getsNombre()+" usa evasion");
	}

	@Override
	public void usarUlti() {
		System.out.println(this.personaje.getsNombre()+" usa disfraz");
		// mayor resistencia o porcentaje de fallo ataque enemigo
	}

}
