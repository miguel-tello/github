package characterKind;

import characterBreed.Character;

public class Druida extends DecoratorKind{

	public Druida(Character perso) {
		super(perso);
		this.personaje.setVida(20);
		this.personaje.setFuerza(1);
		this.personaje.setVelocidad(-13);
		this.personaje.setInteligencia(9);
		this.personaje.setResistencia(10);
	}

	@Override
	public void ataqueNormal() {
		System.out.println(this.personaje.getsNombre()+" usa el conjuro de naturaleza");
	}

	@Override
	public void ataqueEspecial() {
		System.out.println(this.personaje.getsNombre()+" usa conjuro de veneno");
	}

	@Override
	public void defesensa() {
		System.out.println(this.personaje.getsNombre()+" hace crecer un arbol y lo usa como escudo");
	}

	@Override
	public void usarUlti() {
		System.out.println(this.personaje.getsNombre()+" usa cuerpo eterno");
	}

}
