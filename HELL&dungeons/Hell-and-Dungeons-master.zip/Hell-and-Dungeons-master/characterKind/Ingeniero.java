package characterKind;

import characterBreed.Character;

public class Ingeniero extends DecoratorKind{

	public Ingeniero(Character perso) {
		super(perso);
		this.personaje.setVida(15);
		this.personaje.setFuerza(15);
		this.personaje.setVelocidad(15);
		this.personaje.setInteligencia(15);
		this.personaje.setResistencia(15);
	}

	@Override
	public void ataqueNormal() {
		System.out.println(this.personaje.getsNombre()+" usa becario");
	}

	@Override
	public void ataqueEspecial() {
		System.out.println(this.personaje.getsNombre()+" usa codificacion binaria");
		System.out.println("010001001110100100010001100");
	}

	@Override
	public void defesensa() {
		System.out.println(this.personaje.getsNombre()+" usa pantallazo");
	}

	@Override
	public void usarUlti() {
		System.out.println(this.personaje.getsNombre()+" usa juicio verdadero");
	}

}
