package characterKind;

import characterBreed.Character;;

public abstract class DecoratorKind {

	protected Character personaje;
	
	public DecoratorKind(Character perso) {
		this.personaje = perso;
	}
	
	public abstract void ataqueNormal();
	public abstract void ataqueEspecial();
	public abstract void defesensa();
	public abstract void usarUlti();
}
