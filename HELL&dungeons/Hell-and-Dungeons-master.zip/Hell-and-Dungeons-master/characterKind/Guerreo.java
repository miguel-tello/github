package characterKind;

import characterBreed.Character;

public class Guerreo extends DecoratorKind{

	public Guerreo(Character perso) {
		super(perso);
		this.personaje.setVida(11);
		this.personaje.setFuerza(5);
		this.personaje.setVelocidad(-6);
		this.personaje.setInteligencia(5);
		this.personaje.setResistencia(20);
	}

	@Override
	public void ataqueNormal() {
		System.out.println(this.personaje.getsNombre()+" usa espadazo normal");
	}

	@Override
	public void ataqueEspecial() {
		System.out.println(this.personaje.getsNombre()+" usa doble espada");
	}

	@Override
	public void defesensa() {
		System.out.println(this.personaje.getsNombre()+" usa escudo para defenderse");
	}

	@Override
	public void usarUlti() {
		System.out.println(this.personaje.getsNombre()+" usa cambio de arma. Ahora dispara flechas");
		// disminuye velocidad
		//aumenta da�o
	}

}
