package characterKind;

import characterBreed.Character;

public class Inquisidor extends DecoratorKind{

	public Inquisidor(Character perso) {
		super(perso);
		this.personaje.setVida(50);
		this.personaje.setFuerza(-25);
		this.personaje.setVelocidad(-3);
		this.personaje.setInteligencia(-9);
		this.personaje.setResistencia(-12);
	}

	@Override
	public void ataqueNormal() {
		System.out.println(this.personaje.getsNombre()+" usa juicio");
	}

	@Override
	public void ataqueEspecial() {
		System.out.println(this.personaje.getsNombre()+" usa azote mayor");
	}

	@Override
	public void defesensa() {
		System.out.println(this.personaje.getsNombre()+" usa mirada serena");
	}

	@Override
	public void usarUlti() {
		System.out.println(this.personaje.getsNombre()+" usa juicio verdadero");
	}

}
