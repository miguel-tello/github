package characterKind;

import characterBreed.Character;

public class BrujoArcano extends DecoratorKind{

	public BrujoArcano(Character perso) {
		super(perso);
		this.personaje.setVida(-1);
		this.personaje.setFuerza(16);
		this.personaje.setVelocidad(1);
		this.personaje.setInteligencia(12);
		this.personaje.setResistencia(-10);
	}

	@Override
	public void ataqueNormal() {
		System.out.println(this.personaje.getsNombre()+" usa explosion sobrenatural");
	}

	@Override
	public void ataqueEspecial() {
		System.out.println(this.personaje.getsNombre()+" usa recuperacion infernal");
		//recupera vida
	}

	@Override
	public void defesensa() {
		System.out.println(this.personaje.getsNombre()+" usa enga�ar objeto");
	}

	@Override
	public void usarUlti() {
		System.out.println(this.personaje.getsNombre()+" usa creacion de objeto \n y recupera vida, aumenta su salud maxima y aumenta la defensa");
		// vida: 120
		// recuperda: +20
		// defensa: +2
	}

}
