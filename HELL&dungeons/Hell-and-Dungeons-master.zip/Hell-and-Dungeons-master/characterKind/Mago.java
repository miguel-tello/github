package characterKind;

import characterBreed.Character;

public class Mago extends DecoratorKind{

	public Mago(Character character) {
		super(character);
		this.personaje.setVida(-7);
		this.personaje.setFuerza(-10);
		this.personaje.setVelocidad(6);
		this.personaje.setInteligencia(-21);
		this.personaje.setResistencia(10);
	}

	@Override
	public void ataqueNormal() {
		System.out.println(this.personaje.getsNombre()+" le ha golpeado con la bara");
	}

	@Override
	public void ataqueEspecial() {
		System.out.println(this.personaje.getsNombre()+" ha lanzado una bola de fuego");		
	}

	@Override
	public void defesensa() {
		System.out.println(this.personaje.getsNombre()+" ha usado un escudo protecteor para defenderse");
	}

	@Override
	public void usarUlti() {
		System.out.println(this.personaje.getsNombre()+" usa la ulti y obtine \n inmortalidad durante dos turnos");
	}

}
