package game;

import java.util.Random;
import java.util.Scanner;

import characterBreed.Aasimar;
import characterBreed.Character;
import characterBreed.Elfo;
import characterBreed.Enano;
import characterBreed.Fabrica;
import characterBreed.FabricaPersonaje;
import enemy.Enemy;
import enemy.Fabric;
import enemy.FabricaEnemies;
import playerStrategy.Andar;
import playerStrategy.AtaqueEspecial;
import playerStrategy.AtaqueNormal;
import playerStrategy.AtaqueUlti;
import playerStrategy.Defender;
import playerStrategy.NoAtacar;

public class Narrador {
	
	Scanner in = new Scanner(System.in);
	// fabricadores
	private Fabrica fabric = new FabricaPersonaje();
	private FabricaEnemies fEnemy = new Fabric();
	//personajes
	private Character myPersonaje;
	private Enemy myEnemy;
	
	public void welcomePlayer() {
		System.out.println("Bienvenido jugador, antes de jugar necesitamos que crees tu personaje.");
		myPersonaje = fabric.createPlayer(in);
		
		System.out.println("");
		System.out.println("");
		System.out.println("Bienvenido al inframundo "+myPersonaje.getsNombre());
		System.out.println("Estas aqui para expirar tus pecados, para ello tendras que purgar el infierno de los no deseados");
		System.out.println("Ve, camina hacia las entra�as y que comienze la purga");
	}
	
	public void historia() throws InterruptedException {
		// turnos
		int iRand = 0;
		Random rand = new Random(); 
		
		while(true) {
			
			iRand = rand.nextInt(10);
			Thread.sleep(1000);
			
			if(iRand<=5)
				myPersonaje.hacerTurno(new Andar());
			else {
				encuentroEnemigo();
				
				System.out.print("Ataque: " + myPersonaje.getiFuerza() * 0.75 + myPersonaje.getiInteligencia() * 0.25);
				
				/*
				 while(myEnemy.getLife() > 0) {				 
					menuTurno();
					myEnemy.setLife(myEnemy.getLife() - 50);
					
					System.out.println("Vida: "+myEnemy.getLife());
				}
				*/
											
			}
			
			
		}
	}
	
	private void encuentroEnemigo() {
		System.out.println("");
		System.out.println("");
		System.out.println("/*******************************************/");
		myEnemy = fEnemy.createEnemies();
		
		System.out.println(myPersonaje.getsNombre()+" se ha encontrado con un ***"+myEnemy.getKind()+"****");
		
	}
	
	private void menuTurno() {
		
		System.out.println("Esto es lo que puede hacer:");
		System.out.println("1. Hacer un ataque normal");
		System.out.println("2. Realizar el ataque especial");
		System.out.println("3. Defenderse");
		System.out.println("4. No atacar");
		System.out.println("5. Utilizar ulti");
		System.out.print("Que quieres que haga: ");
		
		switch (in.nextInt()) {
			case 1:
				myPersonaje.hacerTurno(new AtaqueNormal());
				break;
			case 2:
				myPersonaje.hacerTurno(new AtaqueEspecial());
				break;
			case 3:
				myPersonaje.hacerTurno(new Defender());
				break;
			case 4:
				myPersonaje.hacerTurno(new NoAtacar());
				break;
			case 5:
				myPersonaje.hacerTurno(new AtaqueUlti());
				break;
		}
	
	}
	
}
