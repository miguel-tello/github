package game;

public interface fabricaPersonajes {
	Character createPlayer();
}
