package game;

import characterBreed.Enano;

public class crearPersonaje implements fabricaPersonajes {

	public void menuCrearPersonaje() {
		System.out.println("Estas son las razas disponibles:");
		System.out.println("1. Enano");
		System.out.println("2. Mediano");
		System.out.println("3. Elfo");
		System.out.println("4. Aasimar");
		System.out.println("5. Fey'ri");
		System.out.print("Que raza desea escoger: ");
	}
	
	@Override
	public Character createPlayer() {
		return new Enano("kjkj");
	}

}
