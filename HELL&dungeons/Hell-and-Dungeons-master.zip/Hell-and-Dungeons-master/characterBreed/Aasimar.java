package characterBreed;

public class Aasimar extends Character{

	public Aasimar(String name) {
		super(name);
		this.setRaza("Aasimar");
		this.setVida(65);
		this.setFuerza(39);
		this.setVelocidad(27);
		this.setInteligencia(40);
		this.setResistencia(35);
	}
}
