package characterBreed;

import java.util.Scanner;

public interface Fabrica {
	Character createPlayer(Scanner in);
}
