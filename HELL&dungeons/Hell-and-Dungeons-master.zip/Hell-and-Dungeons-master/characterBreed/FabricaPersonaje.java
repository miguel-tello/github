package characterBreed;

import java.util.Scanner;

import characterKind.Asesino;
import characterKind.BrujoArcano;
import characterKind.Druida;
import characterKind.Guerreo;
import characterKind.Ingeniero;
import characterKind.Inquisidor;
import characterKind.Mago;
import characterKind.Picaro;
import characterKind.Samurai;
import characterKind.WuJen;

public class FabricaPersonaje implements Fabrica{
	
	private int iRaza = 0;
	
	private void menuCrearPersonaje(Scanner in) {
		
		System.out.println("Para ello escoge una raza, estas son las que estan disponibles:");
		System.out.println("1. Enano");
		System.out.println("2. Mediano");
		System.out.println("3. Elfo");
		System.out.println("4. Aasimar");
		System.out.println("5. Fey'ri");
		System.out.print("Que raza desea escoger: ");
		
		iRaza = in.nextInt();
		
		System.out.println("");

	}
	
	private void menuEscogerClase(Scanner in) {
		System.out.println("Ademas escoge la clase que mas te guste para el");
		System.out.println("1. Samurai");
		System.out.println("2. Mago");
		System.out.println("3. Guerreo");
		System.out.println("4. Asasino");
		System.out.println("5. Wu jen");
		System.out.println("6. Picaro");
		System.out.println("7. Brujo arcano");
		System.out.println("8. Druida");
		System.out.println("9. Inquisidor");
		System.out.println("10. Ingeniero");
		System.out.print("Que raza desea escoger: ");
		
		iRaza = in.nextInt();
		
		System.out.println("");
	}
	
	@Override
	public Character createPlayer(Scanner in) {
		
		Character newCharacter  = null;
		
		String nombre = "";
		
		menuCrearPersonaje(in);
		
		switch (iRaza) {
			case 1:
				System.out.print("Y que nombre quiere darle a su Enano: ");
				nombre=in.next();
				newCharacter = new Enano(nombre);
				break;
				
			case 2:
				System.out.print("Y que nombre quiere darle a su Mediano: ");
				nombre = in.next();
				newCharacter = new Mediano(nombre);
				break;
				
			case 3:
				System.out.print("Y que nombre quiere darle a su Elfo: ");
				nombre = in.next();
				newCharacter = new Elfo(nombre);
				break;
			case 4:
				System.out.print("Y que nombre quiere darle a su Aasimar: ");
				nombre = in.next();
				newCharacter = new Aasimar(nombre);
				break;
			case 5:
				System.out.print("Y que nombre quiere darle a su Fey'ri: ");
				nombre = in.next();
				newCharacter = new Feyri(nombre);
				break;
		}
		
		menuEscogerClase(in);
		
		switch (iRaza) {
			case 1:
				newCharacter.setKindCharacter(new Samurai(newCharacter));
				break;
				
			case 2:
				newCharacter.setKindCharacter(new Mago(newCharacter));
				break;
			case 3:
				newCharacter.setKindCharacter(new Guerreo(newCharacter));
				break;
			case 4:
				newCharacter.setKindCharacter(new Asesino(newCharacter));
				break;
			case 5:
				newCharacter.setKindCharacter(new WuJen(newCharacter));
				break;
			case 6:
				newCharacter.setKindCharacter(new Picaro(newCharacter));
				break;
			case 7:
				newCharacter.setKindCharacter(new BrujoArcano(newCharacter));
				break;
			case 8:
				newCharacter.setKindCharacter(new Druida(newCharacter));
				break;
			case 9:
				newCharacter.setKindCharacter(new Inquisidor(newCharacter));
				break;
			case 10:
				newCharacter.setKindCharacter(new Ingeniero(newCharacter));
				break;
			
		}
		
		return newCharacter;
	}

}
