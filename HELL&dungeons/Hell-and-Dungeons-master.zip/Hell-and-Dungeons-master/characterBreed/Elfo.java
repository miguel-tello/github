package characterBreed;

public class Elfo extends Character{

	public Elfo(String name) {
		super(name);
		this.setRaza("Elfo");
		this.setVida(60);
		this.setFuerza(35);
		this.setVelocidad(60);
		this.setInteligencia(25);
		this.setResistencia(20);
	}
}
