package characterBreed;

public class Mediano extends Character{

	public Mediano(String name) {
		super(name);
		this.setRaza("Mediano");
		this.setVida(50);
		this.setFuerza(20);
		this.setVelocidad(43);
		this.setInteligencia(20);
		this.setResistencia(15);
	}
}
