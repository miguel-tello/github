package characterBreed;

public class Enano extends Character{

	public Enano(String name) {
		super(name);
		this.setRaza("Enano");
		this.setVida(75);
		this.setFuerza(40);
		this.setVelocidad(10);
		this.setInteligencia(30);
		this.setResistencia(30);
	}

}
