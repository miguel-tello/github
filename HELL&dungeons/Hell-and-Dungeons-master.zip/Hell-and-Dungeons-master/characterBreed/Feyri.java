package characterBreed;

public class Feyri extends Character{

	public Feyri(String name) {
		super(name);
		this.setRaza("Fey'ri");
		this.setVida(100);
		this.setFuerza(200);
		this.setVelocidad(5);
		this.setInteligencia(2);
		this.setResistencia(25);
	}
}
