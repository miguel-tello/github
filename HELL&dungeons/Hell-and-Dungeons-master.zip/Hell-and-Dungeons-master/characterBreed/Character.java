package characterBreed;

import characterKind.DecoratorKind;
import characterKind.Mago;
import playerStrategy.StrategyInterface;

public abstract class Character {

	private String sNombre;
	private String sRaza;
	
	private int iVida = 0;
	
	private int iFuerza = 0;
	private int iVelocidad = 0;
	private int iDestreza = 0;
	private int iInteligencia = 0;
	private int iResistencia = 0;
	
	private DecoratorKind kindCharacter;
	private StrategyInterface jugada;
	
	public Character(String name) {
		this.sNombre = name;
		this.kindCharacter = null;
	}
	
	// getter
	public String getsNombre() {
		return sNombre;
	}
	public String getsRaza() {
		return sRaza;
	}
	public int getiFuerza() {
		return iFuerza;
	}
	public int getiVelocidad() {
		return iVelocidad;
	}
	public int getiDestreza() {
		return iDestreza;
	}
	public int getiInteligencia() {
		return iInteligencia;
	}
	public int getResistencia() {
		return iResistencia;
	}
	public int getVida() {
		return iVida;
	}
	
	// setter
	public void setRaza(String sRaza) {
		this.sRaza = sRaza;
	}
	public void setFuerza(int iFuerza) {
		this.iFuerza = this.getiFuerza() + iFuerza;
	}
	public void setVelocidad(int iVelocidad) {
		this.iVelocidad = this.getiVelocidad() + iVelocidad;
	}
	public void setDestreza(int iDestreza) {
		this.iDestreza = this.getiDestreza() + iDestreza;
	}
	public void setInteligencia(int iInteligencia) {
		this.iInteligencia = this.getiInteligencia() + iInteligencia;
	}
	public void setResistencia(int resis) {
		this.iResistencia = this.getResistencia() + resis;
	}
	public void setVida(int iVida) {
		this.iVida = this.getVida() + iVida;
	}
	
	// setter clase
	public void setKindCharacter(DecoratorKind kindCharacter) {
		this.kindCharacter = kindCharacter;
	}
	
	// turno personaje
	public void hacerTurno(StrategyInterface turno) {
		this.jugada = turno;
		this.jugada.performTurn(kindCharacter);
	}
	
}
